const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const auth = require('../../middleware/auth');
const { reviews, saveData } = require('../../config/db');

// Create a new review
router.post('/', auth, (req, res) => {
  try {
    const { bookingId, rating, comment, serviceProvider } = req.body;
    
    const newReview = {
      id: uuidv4(),
      userId: req.user.id,
      bookingId,
      rating,
      comment,
      serviceProvider,
      createdAt: new Date()
    };
    
    reviews.push(newReview);
    saveData();
    
    res.json(newReview);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Get all reviews for current user
router.get('/', auth, (req, res) => {
  try {
    const userReviews = reviews.filter(review => review.userId === req.user.id);
    res.json(userReviews);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Get reviews by booking ID
router.get('/booking/:bookingId', auth, (req, res) => {
  try {
    const bookingReviews = reviews.filter(review => 
      review.bookingId === req.params.bookingId && review.userId === req.user.id
    );
    
    res.json(bookingReviews);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Update review
router.put('/:id', auth, (req, res) => {
  try {
    const { rating, comment } = req.body;
    
    const reviewIndex = reviews.findIndex(review => 
      review.id === req.params.id && review.userId === req.user.id
    );
    
    if (reviewIndex === -1) {
      return res.status(404).json({ message: 'Review not found' });
    }
    
    if (rating) reviews[reviewIndex].rating = rating;
    if (comment) reviews[reviewIndex].comment = comment;
    
    saveData();
    
    res.json(reviews[reviewIndex]);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Delete review
router.delete('/:id', auth, (req, res) => {
  try {
    const reviewIndex = reviews.findIndex(review => 
      review.id === req.params.id && review.userId === req.user.id
    );
    
    if (reviewIndex === -1) {
      return res.status(404).json({ message: 'Review not found' });
    }
    
    reviews.splice(reviewIndex, 1);
    saveData();
    
    res.json({ message: 'Review removed' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

module.exports = router;