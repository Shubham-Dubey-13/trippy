const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const auth = require('../../middleware/auth');
const { 
  mockFlights, 
  mockHotels, 
  mockTrains, 
  mockBuses, 
  bookings, 
  itineraries,
  saveData 
} = require('../../config/db');

// Search for transportation options
router.post('/search-transportation', (req, res) => {
  try {
    const { from, to, date, transportType } = req.body;
    
    let options = [];
    
    switch (transportType) {
      case 'flight':
        options = mockFlights.filter(flight => 
          flight.departure?.city?.toLowerCase() === from?.toLowerCase() && 
          flight.arrival?.city?.toLowerCase() === to?.toLowerCase()
        );
        break;
      case 'train':
        options = mockTrains.filter(train => 
          train.from?.toLowerCase() === from?.toLowerCase() && 
          train.to?.toLowerCase() === to?.toLowerCase()
        );
        break;
      case 'bus':
        options = mockBuses.filter(bus => 
          bus.from?.toLowerCase() === from?.toLowerCase() && 
          bus.to?.toLowerCase() === to?.toLowerCase()
        );
        break;
      default:
        // Return all options if no specific type
        options = [
          ...mockFlights.filter(flight => 
            flight.departure?.city?.toLowerCase() === from?.toLowerCase() && 
            flight.arrival?.city?.toLowerCase() === to?.toLowerCase()
          ),
          ...mockTrains.filter(train => 
            train.from?.toLowerCase() === from?.toLowerCase() && 
            train.to?.toLowerCase() === to?.toLowerCase()
          ),
          ...mockBuses.filter(bus => 
            bus.from?.toLowerCase() === from?.toLowerCase() && 
            bus.to?.toLowerCase() === to?.toLowerCase()
          )
        ];
    }
    
    res.json(options);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Search for accommodation options
router.post('/search-accommodation', (req, res) => {
  try {
    const { location, checkIn, checkOut, guests, roomType, priceRange } = req.body;
    
    let options = mockHotels.filter(hotel => 
      hotel.location?.city?.toLowerCase() === location?.toLowerCase()
    );
    
    // Apply additional filters if provided
    if (roomType) {
      options = options.filter(hotel => 
        hotel.rooms?.some(room => room.type.toLowerCase() === roomType.toLowerCase())
      );
    }
    
    if (priceRange && priceRange.min !== undefined && priceRange.max !== undefined) {
      options = options.filter(hotel => 
        hotel.pricePerNight >= priceRange.min && hotel.pricePerNight <= priceRange.max
      );
    }
    
    res.json(options);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Create booking
router.post('/', auth, (req, res) => {
  try {
    const {
      itineraryId,
      type,
      serviceProvider,
      details,
      price,
      isCombo
    } = req.body;
    
    const bookingReference = uuidv4().substring(0, 8).toUpperCase();
    
    // Calculate discount for combo bookings
    let appliedDiscount = 0;
    if (isCombo) {
      appliedDiscount = price.amount * 0.1; // 10% discount
    }
    
    const newBooking = {
      id: uuidv4(),
      userId: req.user.id,
      itineraryId,
      type,
      serviceProvider,
      details,
      price: {
        amount: price.amount - appliedDiscount,
        currency: price.currency
      },
      status: 'confirmed', // Mock confirmation for demo purposes
      bookingReference,
      isCombo,
      appliedDiscount,
      createdAt: new Date()
    };
    
    bookings.push(newBooking);
    saveData();
    
    res.json(newBooking);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Get all bookings for current user
router.get('/', auth, (req, res) => {
  try {
    const userBookings = bookings.filter(booking => booking.userId === req.user.id);
    
    // Add itinerary information if exists
    const bookingsWithItinerary = userBookings.map(booking => {
      if (booking.itineraryId) {
        const itinerary = itineraries.find(i => i.id === booking.itineraryId);
        if (itinerary) {
          return {
            ...booking,
            itinerary: {
              title: itinerary.title,
              destination: itinerary.destination,
              startDate: itinerary.startDate,
              endDate: itinerary.endDate
            }
          };
        }
      }
      return booking;
    });
    
    res.json(bookingsWithItinerary);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Cancel booking
router.put('/cancel/:id', auth, (req, res) => {
  try {
    const bookingIndex = bookings.findIndex(booking => 
      booking.id === req.params.id && booking.userId === req.user.id
    );
    
    if (bookingIndex === -1) {
      return res.status(404).json({ message: 'Booking not found' });
    }
    
    bookings[bookingIndex].status = 'cancelled';
    saveData();
    
    res.json(bookings[bookingIndex]);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

module.exports = router;