const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const auth = require('../../middleware/auth');
const { itineraries, saveData } = require('../../config/db');

// Create a new itinerary
router.post('/', auth, (req, res) => {
  try {
    const { title, destination, startDate, endDate, activities } = req.body;
    
    const newItinerary = {
      id: uuidv4(),
      userId: req.user.id,
      title,
      destination,
      startDate,
      endDate,
      activities: activities || [],
      createdAt: new Date()
    };
    
    itineraries.push(newItinerary);
    saveData();
    
    res.json(newItinerary);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Get all itineraries for current user
router.get('/', auth, (req, res) => {
  try {
    const userItineraries = itineraries.filter(itinerary => 
      itinerary.userId === req.user.id
    );
    
    res.json(userItineraries);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Get itinerary by ID
router.get('/:id', auth, (req, res) => {
  try {
    const itinerary = itineraries.find(itinerary => 
      itinerary.id === req.params.id && itinerary.userId === req.user.id
    );
    
    if (!itinerary) {
      return res.status(404).json({ message: 'Itinerary not found' });
    }
    
    res.json(itinerary);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Update itinerary
router.put('/:id', auth, (req, res) => {
  try {
    const { title, destination, startDate, endDate, activities } = req.body;
    
    const itineraryIndex = itineraries.findIndex(itinerary => 
      itinerary.id === req.params.id && itinerary.userId === req.user.id
    );
    
    if (itineraryIndex === -1) {
      return res.status(404).json({ message: 'Itinerary not found' });
    }
    
    // Update fields
    if (title) itineraries[itineraryIndex].title = title;
    if (destination) itineraries[itineraryIndex].destination = destination;
    if (startDate) itineraries[itineraryIndex].startDate = startDate;
    if (endDate) itineraries[itineraryIndex].endDate = endDate;
    if (activities) itineraries[itineraryIndex].activities = activities;
    
    saveData();
    
    res.json(itineraries[itineraryIndex]);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Delete itinerary
router.delete('/:id', auth, (req, res) => {
  try {
    const itineraryIndex = itineraries.findIndex(itinerary => 
      itinerary.id === req.params.id && itinerary.userId === req.user.id
    );
    
    if (itineraryIndex === -1) {
      return res.status(404).json({ message: 'Itinerary not found' });
    }
    
    itineraries.splice(itineraryIndex, 1);
    saveData();
    
    res.json({ message: 'Itinerary removed' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

module.exports = router;