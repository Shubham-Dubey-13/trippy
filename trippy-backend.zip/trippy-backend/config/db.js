// New dataStore.js (replaces config/db.js)
const fs = require('fs');
const path = require('path');

// Load mock data
const mockBuses = require('../data/mockBuses.json');
const mockFlights = require('../data/mockFlights.json');
const mockHotels = require('../data/mockHotels.json');
const mockTrains = require('../data/mockTrains.json');

// In-memory data stores
let users = [];
let bookings = [];
let itineraries = [];
let reviews = [];

// Initialize with some data
const initializeData = () => {
  try {
    // Load data if files exist, otherwise use empty arrays
    if (fs.existsSync(path.join(__dirname, '../data', 'users.json'))) {
      users = JSON.parse(fs.readFileSync(path.join(__dirname, '../data', 'users.json')));
    }
    
    if (fs.existsSync(path.join(__dirname, '../data', 'bookings.json'))) {
      bookings = JSON.parse(fs.readFileSync(path.join(__dirname, '../data', 'bookings.json')));
    }
    
    if (fs.existsSync(path.join(__dirname, '../data', 'itineraries.json'))) {
      itineraries = JSON.parse(fs.readFileSync(path.join(__dirname, '../data', 'itineraries.json')));
    }
    
    if (fs.existsSync(path.join(__dirname, '../data', 'reviews.json'))) {
      reviews = JSON.parse(fs.readFileSync(path.join(__dirname, '../data', 'reviews.json')));
    }
    
    console.log('Static data initialized successfully');
  } catch (err) {
    console.error('Error loading static data:', err);
  }
};

// Save data to JSON files (for persistence between server restarts)
const saveData = () => {
  try {
    if (!fs.existsSync(path.join(__dirname, '../data'))) {
      fs.mkdirSync(path.join(__dirname, '../data'), { recursive: true });
    }
    
    fs.writeFileSync(path.join(__dirname, '../data', 'users.json'), JSON.stringify(users, null, 2));
    fs.writeFileSync(path.join(__dirname, '../data', 'bookings.json'), JSON.stringify(bookings, null, 2));
    fs.writeFileSync(path.join(__dirname, '../data', 'itineraries.json'), JSON.stringify(itineraries, null, 2));
    fs.writeFileSync(path.join(__dirname, '../data', 'reviews.json'), JSON.stringify(reviews, null, 2));
  } catch (err) {
    console.error('Error saving static data:', err);
  }
};

// Initialize data
initializeData();

module.exports = {
  mockBuses,
  mockFlights,
  mockHotels,
  mockTrains,
  users,
  bookings,
  itineraries,
  reviews,
  saveData
};