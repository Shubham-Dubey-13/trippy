/**
 * Global error handler utility for consistent error responses
 * @param {Object} res - Express response object
 * @param {Error} error - Error object
 * @param {String} message - Custom error message (optional)
 * @param {Number} statusCode - HTTP status code (default: 500)
 */
exports.handleError = (res, error, message = 'Server error', statusCode = 500) => {
    console.error(`Error: ${message}`, error);
    res.status(statusCode).json({
      success: false,
      message: message,
      error: process.env.NODE_ENV === 'production' ? undefined : error.message
    });
  };
  
  /**
   * Validate request data
   * @param {Object} data - Request data object
   * @param {Array} requiredFields - Array of required field names
   * @returns {Object|null} - Error object or null if valid
   */
  exports.validateRequest = (data, requiredFields) => {
    const missingFields = [];
    
    requiredFields.forEach(field => {
      if (!data[field]) {
        missingFields.push(field);
      }
    });
    
    if (missingFields.length > 0) {
      return {
        message: `Missing required fields: ${missingFields.join(', ')}`,
        statusCode: 400
      };
    }
    
    return null;
  };