const express = require('express');
const cors = require('cors');
const path = require('path');
const dotenv = require('dotenv');
dotenv.config();

// Initialize express app
const app = express();

// Initialize static data store
require('./config/db');

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static('public')); // Serve static files

// Routes
// Routes
const authRoutes = require('./routes/api/auth');
const itineraryRoutes = require('./routes/api/itinerary');
const bookingRoutes = require('./routes/api/booking');
const reviewRoutes = require('./routes/api/review');

app.use('/api/auth', authRoutes);
app.use('/api/itinerary', itineraryRoutes);
app.use('/api/booking', bookingRoutes);
app.use('/api/review', reviewRoutes);
// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).send('Server is running');
});

// SPA fallback (if you have a frontend)
app.get('*', (req, res) => {
  res.sendFile(path.resolve(__dirname, 'public', 'index.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something broke!');
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Static server running on port ${PORT}`);
});